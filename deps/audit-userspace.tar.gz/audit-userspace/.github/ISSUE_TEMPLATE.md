**NOTE:** Please refer to the [Reporting Bug and Requesting Features](https://github.com/linux-audit/audit-documentation/wiki/Reporting-Bugs-and-Requesting-Features) wiki page before creating any new GitHub issues.

