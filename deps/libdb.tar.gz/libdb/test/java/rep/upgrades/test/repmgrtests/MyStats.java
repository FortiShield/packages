/*-
 * Copyright (c) 2010, 2020 Oracle and/or its affiliates.  All rights reserved.
 * 
 * See the file LICENSE for license information.
 *
 */

package repmgrtests;

public class MyStats {
    public long permFailedCount;
    public long egen;
    public long elections;
    public long envId;
    public long master;
}
